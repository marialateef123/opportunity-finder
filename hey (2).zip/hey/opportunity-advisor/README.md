# AI Product Opportunity Advisor

Your Figma UI connected to a Flask backend that reads your pipeline's parquet files.
Nothing about products, complaints, prices or recommendations is hardcoded — every
number on screen comes out of `data/clean/`.

---

## Quick start

```bash
# 1. install
pip install flask pandas pyarrow flask-cors
npm install

# 2. put your parquet files here
#    data/clean/opportunities.parquet
#    data/clean/daraz_niche_gaps.parquet
#    data/clean/features_full.parquet          (optional, adds detail pages)
#    data/clean/validation_results.parquet     (optional, adds growth trends)

# 3. build the UI, then run
npm run build
python server.py
```

Open **http://localhost:5000**

To open it on a phone or another laptop on the same wifi, find your IP
(`ipconfig` on Windows) and use `http://192.168.x.x:5000`.

---

## While you're editing the UI

Two terminals:

```bash
python server.py   # terminal 1 — API on :5000
npm run dev        # terminal 2 — UI with hot reload on :8443
```

Open the Vite URL. In dev mode the frontend calls `http://localhost:5000` for the
API automatically (see `src/api.ts`); in the built version it uses relative URLs,
so one server serves both.

---

## Where your data goes

| File | What the UI uses it for | Required |
|---|---|---|
| `opportunities.parquet` | Every category: demand, competition, prices, complaint, scores | **yes** |
| `daraz_niche_gaps.parquet` | The Pakistan side of every comparison | recommended |
| `features_full.parquet` | Per-category issue breakdown, best-rated products, price bands, sellers | recommended |
| `reviews_topics.parquet` | **Real Amazon review text** shown on the product page | recommended |
| `daraz_reviews_credible.parquet` *(or .csv)* | **Real Daraz review text** shown next to it | recommended |
| `daraz_features_clustered.parquet` | Top Daraz listings per category | optional |
| `product_images.parquet` | **Real Amazon product photos** — see below | optional |
| `validation_results.parquet` | "Picking up fastest" on the trends page | optional |

If an optional file is missing, that section is simply omitted — nothing breaks.
Check what loaded at **http://localhost:5000/api/health**.

Point at a different folder without moving files:

```bash
# Windows
set DATA_DIR=C:\Users\dell\ecommerce-project\data\clean
python server.py
```

---

## API endpoints

| Endpoint | Returns |
|---|---|
| `GET /api/health` | Which parquet files loaded, how many categories |
| `GET /api/overview` | Headline counts for the home page |
| `GET /api/categories` | All categories with scores and labels |
| `GET /api/category/<id>` | One category + issues, top products, price bands, sellers |
| `GET /api/trends` | High demand, growing, declining, most popular |
| `GET /api/gaps` | Quality, price, competition and Pakistan-side gaps |
| `POST /api/recommend` | Personalised shortlist |

`POST /api/recommend` body:

```json
{ "budget": 500000, "units": 200,
  "model": "resell | manufacture | private_label",
  "risk":  "low | balanced | high" }
```

---

## The five-step flow

1. **Products & Reviews** — pick a category, then read actual customer reviews
   pulled from `reviews_topics.parquet` (Amazon) and `daraz_reviews_credible`
   (Daraz), split into what went wrong and what people liked.
2. **Compare Markets** — the same category on both sides: prices, seller counts,
   discounts and the main complaint each market reports.
3. **Trends** — most buyers per product, picking up fastest, where attention sits.
4. **Gaps** — product problems, price gaps, low-competition markets, Pakistan issues.
5. **Your Plan** — budget, quantity, business model, risk → three recommendations.

A step bar at the top tracks progress and lets the user jump back.

## Images

### Product photos

`meta_filtered.parquet` was built with the `images` column dropped, so the photos
are not in your data. To get them:

```bash
# from your ecommerce-project folder (the one with data/clean)
python fetch_product_images.py
```

That streams the Amazon metadata again, keeps only the image URLs for products you
already have, and writes `data/clean/product_images.parquet`. Copy that file into
the advisor's `data/clean` folder and restart — the console will print
`product photos : N`.

If `meta_filtered.parquet` still has an `images` column, that is used instead and
no extra step is needed. Daraz listings use their own
`image` column if your scrape kept it. Anything without a photo falls back to the
category picture, and a failed image falls back to a gradient placeholder.

Category photos are decoration only, never data. They're mapped by category name
in the `IMAGES` dictionary near the top of `server.py`. Change a URL there and it
updates everywhere without rebuilding the UI. If an image fails to load the card
falls back to a gradient placeholder.

## The recommendation logic (unchanged from your pipeline)

1. Budget ÷ units → a per-item price, widened to a 0.4×–2.5× band.
2. Keep categories whose median price falls in that band.
3. `risk: low` drops categories where one seller dominates (HHI > 0.15).
4. `model: manufacture` keeps only categories with an identified complaint —
   if you're making something you need a problem to solve.
5. Weighted score, then top 3:

| model / risk | demand | opportunity | price gap |
|---|---|---|---|
| manufacture | 0.35 | 0.55 | 0.10 |
| private label | 0.45 | 0.45 | 0.10 |
| resell + high risk | 0.70 | 0.20 | 0.10 |
| resell (default) | 0.55 | 0.35 | 0.10 |

Demand is weighted highest for reselling because that is the component the
holdout validation supported.

---

## Business language mapping

The UI never shows raw statistics. `server.py` converts them:

| Underlying value | Shown as |
|---|---|
| `demand_score` | "High demand" / "Steady demand" / "Smaller market" |
| `hhi` (concentration) | "Wide open" / "Some strong sellers" / "Dominated by a few" |
| `quality_score` | "Clear gap" / "Some issues" / "No clear gap" |
| `worst_aspect: size` | "Wrong size" |
| `worst_aspect: wrong_item` | "Wrong item sent" |
| `growth_ratio` | "Growing" / "Steady" / "Slowing" |

Edit the `ASPECT` dictionary and the `band()` calls in `server.py` to change
any of the wording.

---

## Files

```
server.py            Flask backend — loads parquet, serves API + built UI
src/App.tsx          The whole UI (home, categories, detail, trends, gaps, advisor)
src/api.ts           Typed API client — the only place that talks to Flask
src/index.css        Your Figma design tokens, unchanged
data/clean/          Your parquet files go here
dist/                Built UI (created by `npm run build`)
```

---

## Honesty built into the UI

Three things are stated on screen rather than hidden, because they're real
limits of the analysis:

- No cost data exists on either side, so profitability cannot be claimed.
- Prices are not comparable across the two markets; seller counts and complaint
  rates are.
- The demand signal held up in out-of-sample testing; the unmet-need signal did
  not predict growth and is presented as room for a better product, not as a
  forecast.
